<?php
/**
 * Plugin Name: Tắt xml rpc và heartbeat-api wordpress
 * Description: Phát triển bởi Anonymous
 * Version: 1.0.1
 * Author: Anonymous
 */
 

add_filter('xmlrpc_enabled', '__return_false');
add_filter('wp_headers', 'remove_x_pingback');
add_filter('pings_open', '__return_false', 9999);
function remove_x_pingback($headers) {
unset($headers['X-Pingback'], $headers['x-pingback']);
return $headers;
}

add_filter('rest_authentication_errors', function($result) {
    if (!is_user_logged_in()) {
        return new WP_Error('rest_forbidden', 'REST API requests are restricted to authenticated users.', array('status' => 401));
    }
    return $result;
});

add_action('init', 'disable_heartbeat', 1);
function disable_heartbeat() {

	//kiem tra pages in admin
	if(is_admin()) {
		global $pagenow;
		if(!empty($pagenow) && in_array($pagenow, array('admin.php'))) {
			if(!empty($_GET['page'])) {
				$exceptions = array(
					'gf_edit_forms',
					'gf_entries',
					'gf_settings'
				);
				if(in_array($_GET['page'], $exceptions)) {
					return;
				}
			}
		}
	}

	//disable hearbeat chi load bai viet
			global $pagenow;
			if($pagenow != 'post.php' && $pagenow != 'post-new.php') {
				replace_hearbeat();
			}
		
	
}

function replace_hearbeat() {
	wp_deregister_script('heartbeat');
	//wp_dequeue_script('heartbeat');
	if(is_admin()) {
		wp_register_script('hearbeat', plugins_url('disable-xml-rpc_heartbeat-api/js/heartbeat.js', dirname(__FILE__)));
		wp_enqueue_script('heartbeat', plugins_url('disable-xml-rpc_heartbeat-api/js/heartbeat.js', dirname(__FILE__)));
	}
}

/* Heartbeat Frequency thay doi thoi gian mac dinh
/***********************************************************************/
	add_filter('heartbeat_settings', 'heartbeat_frequency');

function heartbeat_frequency($settings) {
		$settings['interval'] = 120;
	return $settings;
}